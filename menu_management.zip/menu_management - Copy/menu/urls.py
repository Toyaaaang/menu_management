from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('menu/', views.Menus, name='Menu'),
    path('menu/details/<int:id>', views.details, name= 'details'),
    path('add/', views.add_menu, name='add_menu'),  
    path('menu/', views.menu_list, name='menu'), 
    path('menu/<int:pk>/', views.menu_details, name='details_menu'),
    path('menu/<int:pk>/edit/', views.update_menu, name='update_menu'),  # Edit member
    path('menu/<int:pk>/delete/', views.delete_menu, name='delete_menu'),
]
    # path('members/<int:pk>/', views.member_details, name='details_member'),  # Member details
     