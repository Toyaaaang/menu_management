from django.http import HttpResponse
from django.template import loader
from .models import Menu
from django.shortcuts import render, redirect, get_object_or_404
from .forms import MenuForm


def Menus(request):
    mymenu = Menu.objects.all().values()
    template = loader.get_template('all_menu.html')
    context = {
        'mymenu': mymenu,
    }
    return HttpResponse(template.render(context, request))

def details(request, id):
    mymenus = Menu.objects.get(id=id)
    template = loader.get_template('details.html')
    context = {
        'mymenus': mymenus,
    }
    return HttpResponse(template.render(context, request))

def main(request):
    template = loader.get_template('index.html')
    return HttpResponse(template.render())


def add_menu(request):
    if request.method == 'POST':
        form = MenuForm(request.POST)
        if form.is_valid():
            form.save()  
            return redirect('menu')  
    else:
        form = MenuForm()

    return render(request, 'add_menu.html', {'form': form})


def menu_list(request):
    menus = Menu.objects.all()
    return render(request, 'menu_list.html', {'menus': menus})



def update_menu(request, pk):
    menu = get_object_or_404(Menu, pk=pk)  # Fetch the member by primary key (ID)
    if request.method == 'POST':
        form = MenuForm(request.POST, instance=menu)  # Pass the member instance to pre-fill the form
        if form.is_valid():
            form.save()  # Save the updated member details
            return redirect('menu')  # Redirect to members list (or details page)
    else:
        form = MenuForm(instance=menu)  # Pre-fill the form with member data

    return render(request, 'update_menu.html', {'form': form, 'menu': menu})



def delete_menu(request, pk):
    menu = get_object_or_404(Menu, pk=pk)  # Fetch the member by ID
    if request.method == 'POST':
        menu.delete()  # Delete the member
        return redirect('menu')  # Redirect to members list

    return render(request, 'delete_menu.html', {'menu': menu})

def menu_details(request, pk):
    menu = get_object_or_404(Menu, pk=pk)  # Fetch the member by primary key (ID)
    return render(request, 'details.html', {'mymenu': menu})